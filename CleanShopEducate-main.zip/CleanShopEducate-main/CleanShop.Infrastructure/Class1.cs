﻿namespace CleanShop.Infrastructure;

public class Class1
{

}
