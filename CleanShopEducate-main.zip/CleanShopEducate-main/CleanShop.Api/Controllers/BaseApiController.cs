using System;
using Microsoft.AspNetCore.Mvc;

namespace CleanShop.Api.Controllers;
[ApiController]
[Route("api/[controller]")]
public class BaseApiController :ControllerBase
{

}
