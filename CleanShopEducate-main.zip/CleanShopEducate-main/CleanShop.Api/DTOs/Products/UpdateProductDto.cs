namespace CleanShop.Api.DTOs.Products;

public record UpdateProductDto(string Name,string Sku,decimal Price,int Stock);

