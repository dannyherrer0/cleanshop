﻿namespace CleanShop.Domain;

public class Class1
{

}
