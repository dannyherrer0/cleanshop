﻿namespace CleanShop.Application;

public class Class1
{

}
